package com.example.tema1_incercare1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class QuizActivity extends AppCompatActivity {

    private ImageView imageQuiz;
    private TextView selectedquiz;
    private String getSelectedQuiz;
    private TextView questionNumber;
    private TextView questionText;

    public static final String questionsize = "questionsize";
    public static final String correctAnswers = "correct_answers";

    private AppCompatButton option1, option2, option3, option4, nextQuestion;
    private int current_position=0;
    private String chosen_answer="";

    //list of questions:
    private List<Question> questionList;
    private String getUsername;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        getSelectedQuiz=getIntent().getStringExtra("SELECTED_QUIZ");
        getUsername=getIntent().getStringExtra("GET_USERNAME");
        initComponents();
    }

    private void initComponents() {
        imageQuiz=findViewById(R.id.enache_andra_roxana_iv_quiz_imagequiz);
        selectedquiz=findViewById(R.id.enache_andra_roxana_tv_quiz_title);
        selectedquiz.setText(getSelectedQuiz);

        questionNumber=findViewById(R.id.enache_andra_roxana_quiz_questionNumber);
        questionText=findViewById(R.id.enache_andra_roxana_quiz_question);

        //options
        option1=findViewById(R.id.enache_andra_roxana_acb_quiz_option1);
        option2=findViewById(R.id.enache_andra_roxana_acb_quiz_option2);
        option3=findViewById(R.id.enache_andra_roxana_acb_quiz_option3);
        option4=findViewById(R.id.enache_andra_roxana_acb_quiz_option4);

        //next question button
        nextQuestion=findViewById(R.id.enache_andra_roxana_acb_quiz_next);
        nextQuestion.setOnClickListener(getNextQClickListener());

        //---------------------------------------------------------
        //setting the questions
        questionList=QuestionList.getQuestions(getSelectedQuiz);
        //quiz image
        imageQuiz.setImageResource(questionList.get(0).getImagePath());
        //afisare progres intrebari
        questionNumber.setText(getString(R.string.question_number,current_position + 1, questionList.size()));
        questionText.setText(questionList.get(0).getQuestionText());

        //setting the options
        option1.setText(questionList.get(0).getOption1());
        option2.setText(questionList.get(0).getOption2());
        option3.setText(questionList.get(0).getOption3());
        option4.setText(questionList.get(0).getOption4());
        //------------------------
        option1.setOnClickListener(getOption1ClickListener());
        option2.setOnClickListener(getOption2ClickListener());
        option3.setOnClickListener(getOption3ClickListener());
        option4.setOnClickListener(getOption4ClickListener());
    }

    private View.OnClickListener getOption1ClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if( chosen_answer.isEmpty()){
                    chosen_answer=option1.getText().toString();
                    option1.setBackgroundResource(R.drawable.round_wrong_answer_red);
                    option1.setTextColor(Color.WHITE);

                    showCorrectAnswer();
                    questionList.get(current_position).setSelected_answer(chosen_answer);
                }
            }
        };
    }

    private View.OnClickListener getOption2ClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if( chosen_answer.isEmpty()){
                    chosen_answer=option2.getText().toString();
                    option2.setBackgroundResource(R.drawable.round_wrong_answer_red);
                    option2.setTextColor(Color.WHITE);

                    showCorrectAnswer();
                    questionList.get(current_position).setSelected_answer(chosen_answer);
                }
            }
        };
    }

    private View.OnClickListener getOption3ClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if( chosen_answer.isEmpty()){
                    chosen_answer=option3.getText().toString();
                    option3.setBackgroundResource(R.drawable.round_wrong_answer_red);
                    option3.setTextColor(Color.WHITE);

                    showCorrectAnswer();
                    questionList.get(current_position).setSelected_answer(chosen_answer);
                }
            }
        };
    }

    private View.OnClickListener getOption4ClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if( chosen_answer.isEmpty()){
                    chosen_answer=option4.getText().toString();
                    option4.setBackgroundResource(R.drawable.round_wrong_answer_red);
                    option4.setTextColor(Color.WHITE);

                    showCorrectAnswer();
                    questionList.get(current_position).setSelected_answer(chosen_answer);
                }
            }
        };
    }

    private View.OnClickListener getNextQClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(chosen_answer.isEmpty()){
                    Toast.makeText(getApplicationContext()
                            , getString(R.string.quiz_choose_answer_continue)
                            , Toast.LENGTH_LONG).show();
                }
                else{
                    changeQuestion();
                }
            }
        };
    }

        //nextQuestion
    private void changeQuestion(){
        current_position++;
        if((current_position+1)==questionList.size()){
            nextQuestion.setText(R.string.quiz_submit_quiz_btn);

        }

        if(current_position<questionList.size()){
            chosen_answer="";
            option1.setBackgroundResource(R.drawable.rounded_background_button);
            option1.setTextColor(Color.BLACK);

            option2.setBackgroundResource(R.drawable.rounded_background_button);
            option2.setTextColor(Color.BLACK);

            option3.setBackgroundResource(R.drawable.rounded_background_button);
            option3.setTextColor(Color.BLACK);

            option4.setBackgroundResource(R.drawable.rounded_background_button);
            option4.setTextColor(Color.BLACK);


            imageQuiz.setImageResource(questionList.get(current_position).getImagePath());
            questionNumber.setText(getString(R.string.question_number_show_progress, current_position + 1, questionList.size()));
            questionText.setText(questionList.get(current_position).getQuestionText());
            //------------------
            option1.setText(questionList.get(current_position).getOption1());
            option2.setText(questionList.get(current_position).getOption2());
            option3.setText(questionList.get(current_position).getOption3());
            option4.setText(questionList.get(current_position).getOption4());

        }
        else{
            Intent intent=new Intent(getApplicationContext(), ScoreActivity.class);
            intent.putExtra(correctAnswers, getCorrectAnswers());
            intent.putExtra(questionsize, questionList.size());
            intent.putExtra("GET_USERNAME", getUsername);
            setResult(RESULT_OK, intent);
            startActivity(intent);
            finish();
        }
    }


    private int getCorrectAnswers() {
        int correct_answers=0;

        for(int i=0;i<questionList.size();i++){
            final String getChosenAnswer= questionList.get(i).getSelected_answer();
            final String getAnswer = questionList.get(i).getAnswer();

            if(getChosenAnswer.equals(getAnswer)) correct_answers++;
        }
        return correct_answers;
    }


    private void showCorrectAnswer(){

            final String getCorrectAnswer= questionList.get(current_position).getAnswer();

            if(option1.getText().toString().equals(getCorrectAnswer)){
                option1.setBackgroundResource(R.drawable.round_correct_answer_green);
                option1.setTextColor(Color.WHITE);
            }
            else if(option2.getText().toString().equals(getCorrectAnswer)){
                option2.setBackgroundResource(R.drawable.round_correct_answer_green);
                option2.setTextColor(Color.WHITE);
            }
            else if(option3.getText().toString().equals(getCorrectAnswer)){
                option3.setBackgroundResource(R.drawable.round_correct_answer_green);
                option3.setTextColor(Color.WHITE);
            }
            else {
                option4.setBackgroundResource(R.drawable.round_correct_answer_green);
                  option4.setTextColor(Color.WHITE);}
    }
}
