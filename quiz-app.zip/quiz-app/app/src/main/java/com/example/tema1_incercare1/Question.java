package com.example.tema1_incercare1;

public class Question {
    private String questionText, option1, option2, option3, option4;
    private int imagePath;
    private String answer, selected_answer;

    public Question(String questionText, String option1, String option2, String option3, String option4, int imagePath, String answer, String selected_answer) {
        this.questionText = questionText;
        this.option1 = option1;
        this.option2 = option2;
        this.option3 = option3;
        this.option4 = option4;
        this.imagePath = imagePath;
        this.answer = answer;
        this.selected_answer = selected_answer;
    }

    public String getQuestionText() {
        return questionText;
    }

    public String getOption1() {
        return option1;
    }

    public String getOption2() {
        return option2;
    }

    public String getOption3() {
        return option3;
    }

    public String getOption4() {
        return option4;
    }

    public String getAnswer() {
        return answer;
    }

    public String getSelected_answer() {
        return selected_answer;
    }

    public int getImagePath() {
        return imagePath;
    }

    public void setSelected_answer(String selected_answer) {
        this.selected_answer = selected_answer;
    }
}
