package com.example.tema1_incercare1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {


    private Button btnLogin;
    private TextInputEditText tietUsername;
    public static final String GET_USERNAME = "GET_USERNAME";
    private String username="";
    private String getUsername;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initComponents();
        getUsername= getIntent().getStringExtra("GET_USERNAME");



    }

    private void initComponents() {
        btnLogin=findViewById(R.id.enache_andra_roxana_btn_main_login_Login);
        tietUsername=findViewById(R.id.enache_andra_roxana_tiet_main_login_username);
        btnLogin.setOnClickListener(getLoginClickListener());


    }

    private View.OnClickListener getLoginClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(tietUsername.getText().toString().trim().isEmpty()){
                    Toast.makeText(getApplicationContext()
                            ,getString( R.string.main_please_enter_name)
                            , Toast.LENGTH_LONG).show();
                }
                else{
                    //validare username
                    if(tietUsername.getText().toString().trim().length()>3) {
                        username = tietUsername.getText().toString();
                        Intent intent = new Intent(getApplicationContext(), ChooseQuizActivity.class);
                        intent.putExtra(GET_USERNAME, username);
                        startActivity(intent);
                        //finish();
                    }
                    else{
                        Toast.makeText(getApplicationContext()
                                , getString(R.string.main_please_valid_name)
                                , Toast.LENGTH_LONG).show();
                    }

                }

            }
        };
    }


}