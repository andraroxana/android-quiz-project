package com.example.tema1_incercare1;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class ChooseQuizActivity extends AppCompatActivity {

    public static final String SELECTED_QUIZ = "SELECTED_QUIZ";
    public static final String Second_quiz = "Pizza Trivia";
    public static final String First_quiz = "Pizza History";
    private String quizAles="";
    private TextView tvUsername;
    private LinearLayout history_pizza;
    private LinearLayout trivia_pizza;
    private Button btnStartQuiz;
    private String getUsername;
    private ActivityResultLauncher<Intent> getUserLauncher;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_quiz);

        initComponents();
        getUsername=getIntent().getStringExtra("GET_USERNAME");
        tvUsername.setText(getString(R.string.hello_user, getUsername));
        getUserLauncher = registergetUserLauncher();

    }

    private ActivityResultLauncher<Intent> registergetUserLauncher() {

        ActivityResultCallback<ActivityResult> callback = getScoreActivityResultCallback();
        return registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), callback);
    }

    private ActivityResultCallback<ActivityResult> getScoreActivityResultCallback(){
        return new ActivityResultCallback<ActivityResult>(){

            @Override
            public void onActivityResult(ActivityResult result) {
                if(result.getResultCode() == RESULT_OK && result.getData()!=null){
                    getUsername=getIntent().getStringExtra("GET_USERNAME");
                    tvUsername.setText(getString(R.string.hello_user, getUsername));
                }
            }
        };

    }


    private void initComponents() {

        history_pizza=findViewById(R.id.enache_andra_roxana_ll_choosequiz_firstquiz);
        trivia_pizza=findViewById(R.id.enache_andra_roxana_ll_choosequiz_secondquiz);
        btnStartQuiz=findViewById(R.id.enache_andra_roxana_btn_choosequiz_startQuiz);
        tvUsername=findViewById(R.id.enache_andra_roxana_tv_choosequiz_username);
        //------------------------
        history_pizza.setOnClickListener(getHistoryquizClickListener());
        trivia_pizza.setOnClickListener(getTriviaPizzaClickListener());

        //startQuiz
        btnStartQuiz.setOnClickListener(getStartQuizClickListener());

    }

    private View.OnClickListener getStartQuizClickListener() {
        return  new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(quizAles.isEmpty()){
                    Toast.makeText(getApplicationContext()
                            , getString(R.string.choose_quiz_to_continue)
                            , Toast.LENGTH_LONG).show();
                }
                else{
                    Intent intent=new Intent(getApplicationContext(), QuizActivity.class);
                    intent.putExtra(SELECTED_QUIZ, quizAles);
                    intent.putExtra("GET_USERNAME", getUsername);
                    getUserLauncher.launch(intent);
                }

            }
        };
    }
    //------SECOND QUIZ------
    private View.OnClickListener getTriviaPizzaClickListener() {
        return  new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                quizAles=Second_quiz;
                trivia_pizza.setBackgroundResource(R.drawable.round_background_stroke);
                history_pizza.setBackgroundResource(R.drawable.rounded_background_white);


            }
        };
    }
    //------FIRST QUIZ------
    private View.OnClickListener getHistoryquizClickListener() {
        return  new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                quizAles=First_quiz;
                history_pizza.setBackgroundResource(R.drawable.round_background_stroke);
                trivia_pizza.setBackgroundResource(R.drawable.rounded_background_white);
            }
        };
    }
}