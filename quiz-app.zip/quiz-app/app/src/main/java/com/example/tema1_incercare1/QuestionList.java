package com.example.tema1_incercare1;

import java.util.ArrayList;
import java.util.List;

public class QuestionList {
    private static List<Question> TriviaPizzaQuestions(){

        final List<Question> questionList= new ArrayList<>();

        questionList.add(new Question("About how many slices of pizza do Americans eat per second?"
                , "16", "210", "350", "500"
                , R.drawable.img_pizza_1, "350", ""));
        questionList.add(new Question("About how many acres worth of pizza do Americans eat each day?"
                , "one acre", "10 acres", "75 acres", "100 acres"
                , R.drawable.t2_tp, "100 acres", ""));

        questionList.add(new Question("The world’s largest pizza was prepared in Rome, Italy, on December 13th, 2012. To the nearest thousand, what was the surface area of this pizza?"
                , "10,000 feet squared", "14,000 feet squared", "18,000 feet squared", "23,000 feet squared"
                , R.drawable.t3_tp, "14,000 feet squared", ""));

        questionList.add(new Question("What is the technical term for the outer edge of a pizza’s crust?"
                , "Cornicione", "Flenicione", "Menicione", "Venicione"
                , R.drawable.t4_tp, "Cornicione", ""));

        questionList.add(new Question("What is the most popular pizza topping in the United States?"
                , "Mushrooms", "Onions", "Pepperoni ", "Sausage"
                , R.drawable.t5_tp, "Pepperoni ", ""));

        questionList.add(new Question("Which month is officially considered to be National Pizza Month?"
                , "February", "July", "October", "December"
                , R.drawable.t6_tp, "October", ""));

        questionList.add(new Question("In 2006, Cristian Dumitru set the world record for the number of pounds of pizza eaten by one person in a single week. How many pounds of pizza did he eat?"
                , "50", "100", "150", "200"
                , R.drawable.t7_tp, "200", ""));

        questionList.add(new Question("Which of the following condiments is common for the Japanese to put on their pizza?"
                , "Ketchup", "Mayonnaise", "Mustard", "Relish"
                , R.drawable.t8_tp, "Mayonnaise", ""));

        questionList.add(new Question("What is the most popular pizza topping in India?"
                , "Chickpeas", "Pickles", "Rice", "Tofu"
                , R.drawable.t9_tp, "Tofu", ""));

        questionList.add(new Question("In 2013, a pizza chain developed DVDs that smelled like pizza. Yes, it’s true. You cannot make something like that up. Which pizza chain was it?"
                , "Little Caesars", "Domino’s", "Papa John’s", "Pizza Hut"
                , R.drawable.t10_tp, "Domino’s", ""));

        questionList.add(new Question("What day of the week is the most popular day to eat pizza in the United States?"
                , "Friday", "Saturday", "Thursday", "Tuesday"
                , R.drawable.t11_tp, "Saturday", ""));

        questionList.add(new Question("Which group of comic book superheroes is known for its love of pizza?"
                , "The Avengers", "The Justice League", "The Outsiders", "The Teenage Mutant Ninja Turtles"
                , R.drawable.t12_tp, "The Teenage Mutant Ninja Turtles", ""));

        questionList.add(new Question("How long does it take Domino’s “World’s Fastest Pizza Maker” to make a single large pizza (to the nearest second)?"
                , "11 seconds", "22 seconds", "30 seconds", "47 seconds"
                , R.drawable.t13_tp, "11 seconds", ""));

        questionList.add(new Question("What percentage of the average slice of pizza is protein?"
                , "12%", "25%", "32%", "40%"
                , R.drawable.t14_tp, "25%", ""));

        return questionList;
    }

    private static List<Question> HistoryPizzaQuestions(){

        final List<Question> questionList= new ArrayList<>();

        questionList.add(new Question("Traditional flatbread is often considered to be the progenitor to the pizza we know and love today. In what country did it originate?"
                , "Egypt", "Greece", "Italy", "Mesopotamia"
                , R.drawable.hq_egipt1, "Egypt", ""));

        questionList.add(new Question("In what year did the first pizzeria in North Korea open?"
                , "1989", "1999", "2009", "2019"
                , R.drawable.hq_korea3, "2009", ""));

        questionList.add(new Question("In what year did the first frozen pizza hit store shelves… er, store freezers?"
                , "1952", "1962", "1972", "1980"
                , R.drawable.hq_frozenpizza2, "1962", ""));

        questionList.add(new Question("Which major war led to the skyrocketing popularity of pizza in the United States?"
                , "Korean War", "Spanish-American War", "World War I", "World War II"
                , R.drawable.hq_ww2_4, "World War II", ""));

        questionList.add(new Question("What was the name of the first pizzeria opened in the United States?"
                , "Lombardi’s Pizza", "Papa’s Tomato Pies", "Santarpio’s Pizza", "Sciortino’s"
                , R.drawable.hq_lombardi5, "Lombardi’s Pizza", ""));

        questionList.add(new Question("Where was pizza first invented?"
                , "Athens, Greece", "Florence, Italy", "Naples, Italy", "Rome, Italy"
                , R.drawable.hq_italy6, "Naples, Italy", ""));

        questionList.add(new Question("Where did Margherita pizza get its name from?"
                , "After its creator’s daughter", "After Queen Margherita of Italy", "After the herb that is commonly placed on top of the pizza", "After the tendency to drink margaritas alongside the pizza"
                , R.drawable.hq_margherita7, "After Queen Margherita of Italy", ""));

        questionList.add(new Question("Which year featured the first documented use of the word “pizza”?"
                , "12462 B.C.E", "3296 B.C.E", "997 C.E.", "1680 C.E."
                , R.drawable.hq_firstpizzaword8, "997 C.E.", ""));

        questionList.add(new Question("In what year was the flatbread invented?"
                , "14000 B.C.E.", "5000 B.C.E", "1000  B.C.E.", "1000 C.E."
                , R.drawable.hq_flatbread9, "14000 B.C.E.", ""));

        questionList.add(new Question("In 1994, pizza became one of the very first items ordered online. What type of pizza was ordered?"
                , "Bacon and sausage pizza", "Hawaiin pizza", "Pepperoni and mushroom pizza with extra cheese", "Supreme pizza with no black olives"
                , R.drawable.hq_net10, "Pepperoni and mushroom pizza with extra cheese", ""));



        return questionList;
    }

    public static List<Question> getQuestions(String selectedQuiz){

        switch (selectedQuiz) {
            case "Pizza History":
                return HistoryPizzaQuestions();
            default:
                return TriviaPizzaQuestions();
        }
    }
}
