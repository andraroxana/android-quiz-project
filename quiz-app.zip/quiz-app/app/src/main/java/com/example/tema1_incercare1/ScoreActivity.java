package com.example.tema1_incercare1;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class ScoreActivity extends AppCompatActivity {

    private TextView tvScore;
    private TextView tvCongrats;
    private String getUsername;
    public static final String GET_USERNAME = "GET_USERNAME";
    private ActivityResultLauncher<Intent> scoreLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score);

        initComponents();

        final int getScore = getIntent().getIntExtra("correct_answers", 0);
        final int getNoQuestions = getIntent().getIntExtra("questionsize", 0);
        getUsername=getIntent().getStringExtra(GET_USERNAME);

        tvCongrats.setText(getString(R.string.congrats_user,getUsername));
        tvScore.setText(getString(R.string.show_score,getScore, getNoQuestions));


    }

    private void initComponents() {
        final AppCompatButton btnNewQuiz=findViewById(R.id.enache_andra_roxana_acb_score_StartNew);
        tvScore=findViewById(R.id.enache_andra_roxana_tv_score_yourscore);
        tvCongrats=findViewById(R.id.enache_andra_roxana_tv_score_congrats);

        btnNewQuiz.setOnClickListener(getStartNewQuizListener());
    }

    private View.OnClickListener getStartNewQuizListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(), ChooseQuizActivity.class);
                intent.putExtra(GET_USERNAME, getUsername);
                setResult(RESULT_OK, intent);
                finish();
            }
        };
    }

    @Override
    public void onBackPressed() {
        Intent intent=new Intent(getApplicationContext(), ChooseQuizActivity.class);
        intent.putExtra(GET_USERNAME, getUsername);
        startActivity(intent);
        finish();
    }
}